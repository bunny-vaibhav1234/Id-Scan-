"use strict";
import React, {Component} from "react";
import {AppRegistry, Dimensions, Image, StyleSheet, Text, TouchableHighlight, View} from "react-native";
import firebase from "react-native-firebase";
import {RNCamera} from "react-native-camera";
import Icon from "react-native-vector-icons/FontAwesome";
import Spinner from "react-native-loading-spinner-overlay";
// import keypair from "keypair";
export default class SelfieVerification extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selfieCaptured: false,
            path: null,
            spinner: false,
            pair: null,
            Aadhar_image_front: null,
            Aadhar_image_back: null,
            Dl_image: null,
            HOTEL_NAME : 'JRD',
            AadharSecondImageTime : null
        };

    }


    static  navigationOptions = ({navigation}) => ({
        title: navigation.state.params.type,

    });

    render() {
        return (
            <View style={styles.container}>
                {this.state.path && this.state.selfieCaptured
                    ? this.renderImage()
                    : this.renderCamera()}
                <Spinner
                    visible={this.state.spinner}
                    textContent={"One moment..."}
                    textStyle={{color: "#fff"}}
                />
            </View>
        );
    }

    renderCamera() {
        return (
            <RNCamera
                ref={ref => {
                    this.camera = ref;
                }}
                style={styles.preview}
                type={RNCamera.Constants.Type.back}
                permissionDialogTitle={"Permission to use camera"}
                permissionDialogMessage={
                    "We need your permission to use your camera phone"
                }
                ratio={"16:9"}
            >
                <View style={{alignItems: 'center'}}>
                    <View style={{flex: 1, justifyContent: 'center'}}>

                        <View style={styles.square}/>
                        <Text style={{fontSize: 20, color: 'white', textAlign: 'center', marginTop: 20}}>

                            {(this.props.navigation.state.params.type == "Aadhaar") ? this.getAadhaarDetails() : this.getDLDetails()}

                        </Text>
                    </View>
                    <TouchableHighlight
                        style={styles.capture}
                        onPress={this.takePicture.bind(this)}
                        underlayColor="rgba(255, 255, 255, 0.5)"
                    >
                        <View/>
                    </TouchableHighlight>
                </View>
            </RNCamera>
        );
    }

    getAadhaarDetails=()=>{
        if (this.state.Aadhar_image_front == null) {
            return "Front side of Aadhaar";
        } else {
            return "Back side of Aadhaar";
        }
    }
   getDLDetails=()=>{
        return "Front side of Driving License";
   }

    renderImage() {
        return (
            <View style={{flex: 1}}>
                <Image
                    style={{flex: 1}}
                    resizeMode="contain"
                    source={{uri: this.state.path}}
                />
                <Icon
                    style={styles.submit}
                    name="arrow-circle-right"
                    size={50}
                    onPress={this.uploadSelfie.bind(this)}
                />
                <Icon
                    style={styles.cancel}
                    name="undo"
                    size={50}
                    onPress={() => this.setState({path: null})}
                />
            </View>
        );
    }


    getChild = () => {

        if (this.props.navigation.state.params.type == "Aadhaar") {

            if (this.state.Aadhar_image_front == null) {
                return "Aadhaar_Front";
            } else {
                return "Aadhaar_Back";
            }

        } else {

            return "DL";

        }
    }

    getDate = () =>{

        let current = new Date();
        let year = current.getFullYear();
        let month = current.getMonth();
        let date = current.getDate();

        let fullDate = year + '-' + month + '-' + date;

        return fullDate;
    }
    getTime = () =>{

        let current = new Date();
        let hour = current.getHours();
        let minutes = current.getMinutes();
        let seconds = current.getSeconds();

        let fullTime = hour + ':' + minutes + ':' + seconds;

        return fullTime;
    }
    getUrl = () => {

        if (this.props.navigation.state.params.type == "Aadhaar") {

            if (this.state.Aadhar_image_front == null) {

                const Aadhaar = 'Aadhaar';
                const Date = this.getDate();
                const Time = this.getTime();
                this.setState({AadharSecondImageTime : Time});
                const url = Aadhaar + '/' + Date + '/' + Time;

                return url;
            }else{

                const Aadhaar = 'Aadhaar';
                const Date = this.getDate();
                const Time = this.state.AadharSecondImageTime;
                const url = Aadhaar + '/' + Date + '/' + Time;

                return url;

                this.setState({AadharSecondImageTime : null});
            }
        }else{
            const DL = 'DL';
            const Date = this.getDate();
            const Time = this.getTime();
            const url = DL+'/'+Date+'/'+Time;

            console.log(url);

            return url;

        }
    }

    uploadSelfie() {
        const {HOTEL_NAME} = this.state;
        const image = this.state.path;
        const URL = HOTEL_NAME+'/'+this.getUrl();

        const imageRef = firebase
            .storage()
            .ref(URL)
            .child(this.getChild());

        let mime = "image/png";
        this.setState({spinner: true});
        const {navigation} = this.props;
        const {state: {params}, navigate} = navigation;
        return imageRef
            .put(image, {contentType: mime})
            .then(() => {
                return imageRef.getDownloadURL();
            })
            .then(url => {
                // URL of the image uploaded on Firebase storage
                /*let data = {
                    method: "POST",
                    body: JSON.stringify({
                        image_url: url,
                        oid: params.person_identifier
                    }),
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json"
                    }
                };
                return fetch("https://api.bharatchain.org/face-compare", data)
                    .then(response => response.json()) // promise
                    .then(json => {
                        console.log(JSON.parse(json))
                        if (JSON.parse(json).match_status == true) {
                            this.setState({ spinner: false });
                            navigate("Profile", {
                                person_identifier: params.person_identifier,
                                imageuri : this.state.path
                            });
                        }
                    })
                    .catch(error => {
                        console.log(error);
                    });*/
                if (url) {
                    console.log(url);
                    this.setState({spinner: false});

                    if (this.props.navigation.state.params.type == "Aadhaar") {

                        if (this.state.Aadhar_image_front == null) {
                            this.setState({Aadhar_image_front: url, path: null});

                        } else if (this.state.Aadhar_image_front !== null) {
                            this.setState({Aadhar_image_back: url});
                            navigate('response', {
                                'type2': this.props.navigation.state.params.type
                            });
                            console.log('front image url:' + this.state.Aadhar_image_front);
                            console.log('back image url:' + this.state.Aadhar_image_back);
                        }

                    } else {
                        navigate('response', {
                            'type2': this.props.navigation.state.params.type
                        })

                    }


                }
            });
    }

    takePicture = async function () {
        this.setState({spinner: true});
        if (this.camera) {
            const options = {quality: 0.5, base64: true};
            const data = await this.camera.takePictureAsync(options);
            console.log(data);
            this.setState({path: data.uri, selfieCaptured: true, spinner: false});
        }
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#000"
    },
    preview: {
        flex: 1,
        justifyContent: "flex-end",
        alignItems: "center",
    },
    capture: {
        width: 70,
        height: 70,
        borderRadius: 35,
        borderWidth: 5,
        borderColor: "#FFF",
        marginBottom: 15,
    },
    square: {
        width: Dimensions.get('window').width - 10,
        height: 250,
        borderWidth: 2,
        borderColor: "#fff",
    },
    cancel: {
        position: "absolute",
        left: 20,
        bottom: 20,
        backgroundColor: "transparent",
        color: "#FFF",
        fontWeight: "600"
    },
    submit: {
        position: "absolute",
        right: 20,
        bottom: 20,
        backgroundColor: "transparent",
        color: "#FFF",
        fontWeight: "600"
    }
});

AppRegistry.registerComponent("SelfieVerification", () => SelfieVerification);
