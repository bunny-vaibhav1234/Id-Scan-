/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, {Component} from 'react';
import {Container , Footer , FooterTab , Text} from 'native-base';
import {StyleSheet , TouchableOpacity} from 'react-native';
import Content from './components/content';


export default class App extends Component {



    render() {
        return (
            <Container style={styles.container}>
                <Content navigation={this.props.navigation}/>
                <Footer >
                    <FooterTab style={{backgroundColor:'#fff', padding:10 , justifyContent:'center'}}>
                        <Text style={{color:'royalblue'}}>Powered By ERA</Text>
                    </FooterTab>
                </Footer>
            </Container>

        );
    }

}
let styles = StyleSheet.create({
    container: {
        flex:1,
        justifyContent:'center',
        backgroundColor:'royalblue',
    }
});

