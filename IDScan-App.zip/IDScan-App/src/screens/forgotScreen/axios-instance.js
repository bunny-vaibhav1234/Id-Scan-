import axios from 'axios';

export const axiosinstance = axios.create({
    baseURL: 'https://api.erascan.com/',
    timeout: 15000,
    headers: {
        'Content-Type': 'application/json',
    }
});
