import React, {Component} from 'react';
import { Card , CardItem,View , Text , Input, Item, Left , Right , Body , Button , Icon} from 'native-base';
import {Image , KeyboardAvoidingView , AsyncStorage , TouchableOpacity} from 'react-native';
import Icon1 from 'react-native-vector-icons/FontAwesome';
import Key from 'react-native-vector-icons/Ionicons';
import {axiosinstance} from "../axios-instance";


export default class content extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            username:'',
            password:'',
            validated:null
        }
    }

    componentDidMount(){
        this._loadInitialState().done();
    }

    _loadInitialState = async () =>{
        let value = await AsyncStorage.getItem('user');
        if (value){
            this.props.navigation.navigate('Home');
        }
    }


    getRequest = ()=>{
        return axiosinstance.post('/manager/tokens/login',
            {
                email: this.state.username,
                password: this.state.password
            })
    }
    validate = (email) =>{
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
        if(email === null){
            this.setState({validated:null});
        }else {
            if (reg.test(email) === false) {
                this.setState({validated: false});
            } else {
                this.setState({validated: true , username: email});
            }
        }
    }

    login = ()=>{

        if(this.state.validated) {

            this.getRequest().then((response) => {
                console.log(response.data.token);
            }).then((res) => {
                console.log(res);
                this.props.navigation.navigate('Home');
            }).done();
        }else{
            alert('Your credentials are wrong')
        }

       /* fetch('',{
            method:'POST',
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                username:this.state.username,
                password:this.state.password
            }),
        }).then((response) => response.json()).then((res)=>{

            if(res.success === true){
                AsyncStorage.setItem('user' , res.user);
                this.props.navigation.navigate('Home');
            }else{
                alert(res.message);
            }
        }).done();*/

    }

    render() {
        return (

            <View style={styles.container}>
                <View style={{display: 'flex', flex: 1, flexDirection: 'column', justifyContent: 'center'}}>
                    <View style={{alignItems: 'center', paddingBottom: 20}}>
                        <Image source={require('../../../../asset/img/logo.png')} style={{height: 80, width: 60}}/>
                    </View>
                    <Item  regular style={{marginBottom: 10, backgroundColor: '#fff'}}>
                        <Icon1 name={'user'} size={30} style={{paddingRight: 10, paddingLeft: 20}}/>
                        <Input placeholder={'Enter your Email'}

                               onChangeText={(username)=> this.validate(username)}/>

                        { (this.state.validated == false) ?
                        <Icon name={'close-circle'} style={{color:'red'}}/> : <Icon name={'checkmark-circle'} style={{color:'green'}}/>}
                    </Item>
                    {/*<Item regular style={{marginBottom: 10, backgroundColor: '#fff'}}>
                        <Key name={'md-key'} size={30} style={{paddingRight: 10, paddingLeft: 20}}/>
                        <Input placeholder={'Enter your Email'}
                               secureTextEntry
                               onChangeText={(password)=> this.setState({password})}/>
                    </Item>*/}



                    <Button full light bordered onPress={this.login}><Text>Reset Password </Text></Button>
                    <TouchableOpacity style={{ alignItems:'center' , padding:10}}>
                        <Text style={{color:'#fff'}} onPress={()=> this.props.navigation.navigate('loginScreen')}>Login with ERA</Text>
                    </TouchableOpacity>
                </View>
            </View>

        );
    }
}


const styles = {
    container:{
        flex:1,
        padding:20
    }
}
