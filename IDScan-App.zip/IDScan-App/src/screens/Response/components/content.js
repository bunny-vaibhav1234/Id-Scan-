import React, {Component} from 'react';
import { Card , CardItem , View , Text , Header , Button} from 'native-base';
import {Image, TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'


   const content = (props)=>{
        return (
            <View style={styles.container}>
                <View style={{alignItems:'center' }}>
                <Icon name={'md-checkmark-circle-outline'} size={200} style={{color:'#43A047'}}/>
                <Text style={styles.text}>Your {props.navigation.state.params.type2} Is Uploaded Successfully</Text>
                </View>
                <TouchableOpacity  style={styles.touchableOpacity}  onPress={()=>props.navigation.navigate('Home')}>
                    <Icon name={'ios-arrow-back-outline'} style={{color:'#fff', paddingRight:10 }} size={50}/>
                    <Text style={{color:'#fff'}}>Go To Home</Text>
                </TouchableOpacity>
            </View>
        );
    }


const styles = {
    container: {
        padding:30,
        flex:1,
        justifyContent:'space-evenly',
        alignItems:'center'
    },
    text:{
        fontSize:15,
        fontWeight:'100',
    },
    touchableOpacity:{
        backgroundColor:'royalblue' ,
        borderRadius:50 ,
        padding:20,
        display:'flex',
        flexDirection : 'row',
        alignItems:'center',
        justifyContent:'center'
    }
}

export default  content;