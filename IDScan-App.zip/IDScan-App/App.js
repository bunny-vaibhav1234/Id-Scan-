
import React from 'react';
import { StyleSheet, Text, View , YellowBox} from 'react-native';
YellowBox.ignoreWarnings(['Warning: isMounted(...) is deprecated', 'Module RCTImageLoader']);
import {createStackNavigator} from 'react-navigation';
import  {HeaderBackButton} from  'react-navigation';
import Camera from './src/screens/cameraFeed';
import frontScreen from './src/screens/Home';
import Response from './src/screens/Response';
import LoginScreen from './src/screens/LoginScreen';
import ForgotScreen from './src/screens/forgotScreen';
import {AsyncStorage} from 'react-native';

export  default createStackNavigator({
    Home:{
        screen : frontScreen,
        navigationOptions:{
            title : 'Home'
        }
   },
    cameraScreen :{
        screen:Camera,
    },
    response:{
        screen:Response,
        navigationOptions : {
            title:'Verified'
        }
    },
    loginScreen : {
        screen: LoginScreen,
        navigationOptions : {
            header:null
        }
    },
    forgotScreen : {
        screen : ForgotScreen,
        navigationOptions : {
            header:null
        }
    }

},
{
    initialRouteName: !AsyncStorage.getItem('token') ? 'loginScreen' : 'Home',
    navigationOptions: ({navigation}) => ({
        headerStyle: {
            backgroundColor: 'royalblue',
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
            fontWeight: 'bold',
        }
    })

},);
